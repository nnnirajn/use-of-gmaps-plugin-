var map = new GMaps({
  div: '.map',
  lat: 18.559485,
  lng: 73.931178,
  zoom:16   /*as number increse will zoom in */ 
});
  
map.addMarker({
      lat: 18.559485,
      lng: 73.931178,
      title: 'sangharsh chowk by Niraj',
     
      infoWindow: {
        content: '<p>Niraj Narkhede</p>'
      }
});